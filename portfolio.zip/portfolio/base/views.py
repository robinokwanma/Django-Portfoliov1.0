from django.shortcuts import render 
from .forms import Contactform
from django.conf import settings
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
# Create your views here.

def home(request):
    form = Contactform()
    context = {'form':form}
    return render (request, 'base/index.html', context)

def sendEmail(request):

	if request.method == 'POST':

		template = render_to_string('base/email_template.html', {
			'name':request.POST.get('name'),
			'email':request.POST.get('email'),
			'message':request.POST.get('message'),
            'country':request.POST.get('country')
			})

		email = EmailMessage(
			request.POST.get('subject'),
			template,
			settings.EMAIL_HOST_USER,
			['info@cyber.ng']
			)

		email.fail_silently=False
		email.send()

	return render(request, 'base/email_successful.html')