from tkinter import Menu, Widget
from django.forms import ChoiceField, ModelForm, TextInput, EmailInput, Textarea, Select
from .models import Contactrobin

class Contactform(ModelForm):
    class Meta:
        model = Contactrobin
        fields = ['name', 'email', 'subject', 'country', 'message']
        widgets = {
            'name': TextInput(attrs={
                'class': "inputfield",
                'style': '',
                'placeholder': 'Your Full Name'
                }),
            'email': EmailInput(attrs={
                'class': "inputfield", 
                'style': '',
                'placeholder': 'Your Email'
                }),
             'subject': TextInput(attrs={
                'class': "inputfield", 
                'style': '',
                'placeholder': 'Subject'
                }),
            'message': Textarea(attrs={
                'class': "inputfield", 
                'style': '',
                'placeholder': 'Type your message here!'
                }),
            'country': Select(attrs={
                'class': "inputfield", 
                'style': '',

                })
            
        }
                