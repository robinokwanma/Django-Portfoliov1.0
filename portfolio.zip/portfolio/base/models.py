from django.db import models
from django_countries.fields import CountryField
# Create your models here.

class Contactrobin(models.Model):
    name = models.CharField(max_length=200, null=True)
    email = models.EmailField(null=False)
    subject = models.CharField( max_length=200, null=False)
    country = CountryField( null=False )
    message = models.TextField(null=False, blank=False)