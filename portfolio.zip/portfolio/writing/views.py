from django.shortcuts import render
from base.forms import Contactform
# Create your views here.
def writer(request):
    form = Contactform()
    context = {'form':form}
    return render(request, 'writing/writemore.html', context)