from django.shortcuts import render
from base.forms import Contactform

# Create your views here.
def wordpress(request):
    form = Contactform()
    context = {'form':form}
    
    return render(request, 'wordpress/wpmore.html', context)