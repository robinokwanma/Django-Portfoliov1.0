from django.shortcuts import render
from base.forms import Contactform
from .models import WebDevelopment

# Create your views here.
def webdev(request):
    form = Contactform()
    webdevart = WebDevelopment.objects.all
    context = {'webdevart':webdevart,
               'form':form}
    
    return render(request, 'webdev/wdevmore.html', context)