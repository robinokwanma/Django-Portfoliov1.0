from logging import PlaceHolder
from tkinter import CASCADE
from django.db import models

# Create your models here.
class WebDevelopment(models.Model):
    title = models.CharField(max_length= 200)
    featuredimage = models.ImageField(null=True, blank=True, upload_to="img", default="img/placeholder.png")
    about = models.TextField(blank=True, null= True)
    
    def __str__(self):
        return self.title