from django.contrib import admin
from .models import WebDevelopment

# Register your models here.

admin.site.register(WebDevelopment)